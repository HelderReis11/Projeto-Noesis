Executar o ficheiro

abrir o browser e colocar o link: localhost:8080

para consulta das tabelas de base de dados em H2 usar: localhost:8080/h2-console

JDBC URL: jdbc:h2:mem:testdb

User Name: sa

"Connect" é possível ver as tabelas: Candidatos e Profissoes