package com.devs.desafio;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping (value = "/api/candidatos")
public class CandidatoController {

    @Autowired //para instanciar automaticamente
    private CandidatoRepository rep;

    @PostMapping
    public Candidato add_candidato(@RequestBody Candidato candidato){
        return rep.save(candidato);
    }
    @GetMapping
    public List<Candidato> findAll(){
        return rep.findAll();
    }

    @DeleteMapping("/{id}")
    public void deleteCandidato(@PathVariable Long id) {
        rep.deleteById(id);
    }

    @GetMapping("/{id}")
    public Candidato getCandidato(@PathVariable Long id) {
        if(rep.findById(id).isPresent())
            return rep.findById(id).get();
        return null;
    }

    @PutMapping("/{id}")
    public Candidato updateCandidato(@PathVariable Long id, @RequestBody Candidato candidatoAtualizado) {

        Candidato candidatoExistente = rep.findById(id).get();
        candidatoExistente.setNome(candidatoAtualizado.getNome());
        candidatoExistente.setContacto(candidatoAtualizado.getContacto());
        candidatoExistente.setIdade(candidatoAtualizado.getIdade());
        candidatoExistente.setMorada(candidatoAtualizado.getMorada());
        candidatoExistente.setProfissao(candidatoAtualizado.getProfissao());

        return rep.save(candidatoExistente);
    }
}
