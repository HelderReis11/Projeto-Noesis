document.addEventListener("DOMContentLoaded", function () {
    const addButton = document.getElementById("add-candidate")
    const candidateForm = document.getElementById("candidate-form");
    const tableBody = document.querySelector("#candidate-table tbody");
    let candidateIdToSave = -1

    profissoes = {
        1 : "Estudante",
        2 : "Desempregado",
        3 : "Trabalhador por conta de outrem",
        4 : "Trabalhador por conta própria",
        5 : "Outro"
    }

    //ADICIONAR CANDIDATO
    addButton.addEventListener("click", function() {
        addCandidate();
    });

    // Função para adicionar candidato
    function addCandidate() {
        // Valores do formulário
        const name = document.getElementById("name").value;
        const contact = document.getElementById("contact").value;
        const age = document.getElementById("age").value;
        const address = document.getElementById("address").value;
        //FIXME
        const professionName = document.getElementById("profession").value;
        let profId = 0

        for(let id in profissoes){
            if(profissoes[id] === professionName) profId = id;
        }

        const newCandidate = {
            nome: name,
            contacto: contact,
            idade: age,
            morada: address,
            profissao: {
                id: profId,
                descricao: professionName
            }
        };

        fetch('/api/candidatos', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(newCandidate)
        })
            .then(response => response.json())
            .then(data => {
                console.log(data);

                // Reset do formulário
                candidateForm.reset();

                // Refresh
                location.reload();

            })
            .catch(error => {
                console.error(error);
            });
    }

    //PREENCHER TABELA
    function fillCandidateTable(data) {

        data.forEach(candidate => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${candidate.id}</td>
                <td>${candidate.nome}</td>
                <td>${candidate.contacto}</td>
                <td>${candidate.idade}</td>
                <td>${candidate.morada}</td>
                <td>${candidate.profissao?.descricao}</td>
                <td>
                <button class="delete-button" data-id="${candidate.id}">Eliminar</button>
                <button class="edit-button" data-id="${candidate.id}">Editar</button>
                </td>
            `;

            tableBody.appendChild(row);
        });
    }

    // GET para obter todos os candidatos
    fetch('/api/candidatos')
        .then(response => response.json())
        .then(data => {
            fillCandidateTable(data);
        })
        .catch(error => {
            console.error(error);
        });


    //DELETE
    document.addEventListener("click", function (event) {
        if (event.target.classList.contains("delete-button")) {
            const candidateIdToDelete = event.target.getAttribute("data-id");
            deleteCandidate(candidateIdToDelete);
        }

        function deleteCandidate(candidateId) {
            fetch(`/api/candidatos/${candidateId}`, {
                method: 'DELETE',
            })
                .then(response => {
                    if (response.ok) {
                        // Refresh
                        location.reload();
                    } else {
                        console.error("Erro ao excluir o candidato.");
                    }
                })
                .catch(error => {
                    console.error(error);
                });
        }
    });

    //EDITAR
    document.addEventListener("click", function (event) {
        if (event.target.classList.contains("edit-button")) {
            // ID do candidato a ser editado a partir do atributo data-id
            const candidateIdToEdit = event.target.getAttribute("data-id");
            candidateIdToSave = candidateIdToEdit

            loadCandidateDataForEditing(candidateIdToEdit);

            // Exibir o pop-up
            document.getElementById("edit-popup").style.display = "block";
        }

        function loadCandidateDataForEditing(candidateId) {
            fetch(`/api/candidatos/${candidateId}`)
                .then(response => response.json())
                .then(data => {
                    // Preencha os campos do pop-up de edição com os dados do candidato
                    document.getElementById("edit-name").value = data.nome;
                    document.getElementById("edit-contact").value = data.contacto;
                    document.getElementById("edit-age").value = data.idade;
                    document.getElementById("edit-address").value = data.morada;
                    document.getElementById("edit-profession").value = data.profissao.descricao;

                })
                .catch(error => {
                    console.error(error);
                });
        }
    });

    //SALVAR O EDITADO
    document.getElementById("save-edited-candidate").addEventListener("click", function() {
        updateCandidate();
    });

    function updateCandidate() {
        const editedName = document.getElementById("edit-name").value;
        const editedContact = document.getElementById("edit-contact").value;
        const editedAge = document.getElementById("edit-age").value;
        const editedAddress = document.getElementById("edit-address").value;
        const editedProfession = document.getElementById("edit-profession").value;

        let profId = 0

        for(let id in profissoes){
            if(profissoes[id] === editedProfession) profId = id;
        }

        const editedCandidate = {
            nome: editedName,
            contacto: editedContact,
            idade: editedAge,
            morada: editedAddress,
            profissao: {
                id: profId,
                descricao: editedProfession
            }
        };



        fetch(`/api/candidatos/${candidateIdToSave}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(editedCandidate)
            })
                .then(response => response.json())
                .then(data => {
                    console.log(data);

                    // Fechar o pop-up
                    document.getElementById("edit-popup").style.display = "none";

                    location.reload();

                })
                .catch(error => {
                    console.error(error);
                });
    }

});